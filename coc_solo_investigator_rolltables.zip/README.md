# Solo Investigator Rollable Tables for Call of Cthulhu 7e

Rollable tables from the Solo Investigator Handbook. This module contains base oracles to facilitate solo play. For more info, tables and the rules on how to use these tables properly please support the creators of the book this is based on.

The Solo Investigator's Handook was created by Paul Bimler.

### [Get the book here](https://www.drivethrurpg.com/en/product/266779/The-Solo-Investigators-Handbook)
